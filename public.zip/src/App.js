
import FAQs from "./FAQ/FAQs";


function App() {
  return (
      <div className='App'>
       els
      </div>
  );
}

export default App;
